// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom exception class derived from std::exception
// Created to satisfy requirement to create, throw, and catch a custom exception
class CustomException : public std::exception
{
public:
    const char* what() const noexcept override
    {
        return "Custom application exception occurred.";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    // Throwing a standard runtime_error exception
    throw std::runtime_error("Error in even more custom application logic.");

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    std::cout << "Running Custom Application Logic." << std::endl;

    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e)
    {
        // Catching standard exception and displaying message
        std::cout << "Exception caught in do_custom_application_logic: "
            << e.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    // Throwing our custom exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // Check for divide by zero
    if (den == 0)
    {
        // Throwing a standard invalid_argument exception
        throw std::invalid_argument("Division by zero error.");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& e)
    {
        // Catching only the divide exception
        std::cout << "Division Exception: " << e.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& e)
    {
        // Catch custom exception first
        std::cout << "Custom Exception Caught: " << e.what() << std::endl;
    }
    catch (const std::exception& e)
    {
        // Catch standard exceptions
        std::cout << "Standard Exception Caught: " << e.what() << std::endl;
    }
    catch (...)
    {
        // Catch-all handler for any unknown exceptions
        std::cout << "Unknown Exception Caught!" << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu