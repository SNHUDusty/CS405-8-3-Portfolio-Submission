﻿// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <ctime>
#include <filesystem>

using namespace std;

// encrypt or decrypt a string using a key
string encrypt_decrypt(const string& source, const string& key)
{
    const auto key_length = key.length();
    const auto source_length = source.length();

    assert(key_length > 0);
    assert(source_length > 0);

    string output = source;

    for (size_t i = 0; i < source_length; ++i)
    {
        // simple XOR encryption
        output[i] = source[i] ^ key[i % key_length];
    }

    return output;
}

// read file contents
string read_file(const string& file_name)
{
    ifstream file(file_name);

    if (!file.is_open())
    {
        cerr << "Error opening file: " << file_name << endl;
        return "";
    }

    stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// save encrypted/decrypted data
void save_data_file(const string& file_name, const string& data)
{
    ofstream file(file_name);

    if (!file.is_open())
    {
        cerr << "Error writing file: " << file_name << endl;
        return;
    }

    file << data;
}

int main()
{
    cout << "Encryption Decryption Test!" << endl;

    // 🔍 SHOW WHERE PROGRAM IS LOOKING
    cout << "Current Path: " << filesystem::current_path() << endl;

    string input_file = "inputdatafile.txt";
    string encrypted_file = "encrypteddatafile.txt";
    string decrypted_file = "decrypteddatafile.txt";

    string key = "simplekey";

    // read original file
    string original_data = read_file(input_file);

    if (original_data.empty())
    {
        cerr << "File read failed. Check file location.\n";
        return 1;
    }

    // encrypt
    string encrypted_data = encrypt_decrypt(original_data, key);
    save_data_file(encrypted_file, encrypted_data);

    // decrypt
    string decrypted_data = encrypt_decrypt(encrypted_data, key);
    save_data_file(decrypted_file, decrypted_data);

    cout << "Read File: " << input_file
        << " - Encrypted To: " << encrypted_file
        << " - Decrypted To: " << decrypted_file << endl;

    return 0;
}